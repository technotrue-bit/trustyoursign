import { useEffect, useState, type ComponentType } from "react";
import {
  BookOpen,
  Columns3,
  Compass,
  Hexagon,
  MessageCircle,
  PersonStanding,
  Table2,
} from "lucide-react";
import { LIBRARY, useNativity } from "@/lib/chart/nativity";
import type { AppMode } from "@/lib/chart/types";
import { CONSTELLATIONS } from "@/lib/galaxy/constellations";
import { useGalaxy } from "@/lib/galaxy/store";
import { ensureAutoClock, ensureFlyInput, galaxyTravel, noteControl, skipBirth } from "@/lib/galaxy/travel";
import { buryWebGLCanvas, canWebGL, shouldUse3D } from "@/lib/gpu";
import { useVault } from "@/lib/store";
import { cn } from "@/lib/utils";
import { SceneErrorBoundary } from "../scene-error-boundary";
import { AskPanel } from "./AskPanel";
import { BirthChat } from "./BirthChat";
import { DetailPanel } from "./DetailPanel";
import { FallbackSky } from "./FallbackSky";
import { Gloss, GlossRoot, GlossStage } from "./Gloss";
import { SignStrip } from "./SignStrip";
import { StarBack } from "./StarBack";

const MODES: { id: AppMode; label: string; icon: typeof Compass }[] = [
  { id: "sky", label: "Sky", icon: Compass },
  { id: "body", label: "Body", icon: PersonStanding },
  { id: "gates", label: "Gates", icon: Columns3 },
  { id: "machine", label: "Machine", icon: Hexagon },
  { id: "readings", label: "Readings", icon: BookOpen },
  { id: "bones", label: "Bones", icon: Table2 },
  { id: "ask", label: "Ask", icon: MessageCircle },
];

export function VaultApp() {
  const [Scene, setScene] = useState<ComponentType | null>(null);
  const [sceneFailed, setSceneFailed] = useState(false);
  const entered = useVault((s) => s.entered);
  const gate = useVault((s) => s.gate);
  const chat = useVault((s) => s.chat);

  useEffect(() => {
    if (!shouldUse3D()) {
      setSceneFailed(true);
      return;
    }
    let cancelled = false;
    void import("@/components/scene/ChartCanvas")
      .then((m) => {
        if (!cancelled && canWebGL()) setScene(() => m.ChartCanvas);
        else if (!cancelled) setSceneFailed(true);
      })
      .catch(() => {
        if (!cancelled) setSceneFailed(true);
      });
    const onLost = () => setSceneFailed(true);
    const hideLost = (e: Event) => {
      const t = e.target;
      if (t instanceof HTMLCanvasElement && t.closest(".canvas-root")) buryWebGLCanvas(t);
    };
    window.addEventListener("vault-webgl-lost", onLost);
    window.addEventListener("webglcontextlost", hideLost, true);
    return () => {
      cancelled = true;
      window.removeEventListener("vault-webgl-lost", onLost);
      window.removeEventListener("webglcontextlost", hideLost, true);
    };
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        const st = useVault.getState();
        if (st.selection) st.clear();
        else st.goBack();
      }
      if (e.key === "Enter" && !useVault.getState().entered) {
        const st = useVault.getState();
        if (st.gate === "galaxy") {
          if (st.chat) return;
          if (galaxyTravel.birth < 1) {
            skipBirth();
            useGalaxy.getState().markBorn();
            return;
          }
          const g = useGalaxy.getState();
          if (g.moved) {
            const sign = CONSTELLATIONS[g.signIndex];
            if (sign) st.openBirthChat(sign.id);
          } else st.openLibrary();
        }
      }
      const n = Number(e.key);
      if (n >= 1 && n <= 7) {
        const mode = MODES[n - 1];
        if (mode && useVault.getState().entered) useVault.getState().setMode(mode.id);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    ensureAutoClock();
    ensureFlyInput();
  }, []);

  useEffect(() => {
    galaxyTravel.busy = Boolean(chat || entered);
  }, [chat, entered]);

  return (
    <main
      className="relative h-dvh min-h-full w-full overflow-hidden bg-bg text-fg"
      style={{ background
... 