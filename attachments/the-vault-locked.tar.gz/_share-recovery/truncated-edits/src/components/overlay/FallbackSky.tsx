    const tick = (now: number) => {
      raf = requestAnimationFrame(tick);
      try {
        tickSky(now);
      } catch {
        /* never let a bad frame kill the sky */
      }
    };

    const tickSky = (now: number) => {
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;