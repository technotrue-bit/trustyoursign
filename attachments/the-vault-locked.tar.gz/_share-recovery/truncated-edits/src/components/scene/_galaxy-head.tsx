import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import {
  AdditiveBlending,
  BufferAttribute,
  BufferGeometry,
  CanvasTexture,
  Color,
  Group,
  InstancedMesh,
  LinearFilter,
  LineSegments,
  Mesh,
  Object3D,
  PerspectiveCamera,
  Points,
  SRGBColorSpace,
  Vector3,
} from "three";
import { isSmallGpu } from "@/lib/gpu";
import {
  CONSTELLATIONS,
  constellationDust,
  pairFigures,
  wrap12,
  type Constellation,
} from "@/lib/galaxy/constellations";
import {
  CRUISE,
  MAX_FLY,
  alongToGate,
  birthBoom,
  birthIgnite,
  ensureAutoClock,
  galaxyTravel,
  gateForm,
  noteControl,
  prefersReducedMotion,
  signMorph,
  skipBirth,
  starSpark,
  stepBirth,
} from "@/lib/galaxy/travel";
import { useGalaxy } from "@/lib/galaxy/store";
import { makeSparkMaterial } from "@/lib/galaxy/starRender";
import { useVault } from "@/lib/store";

const SPACING = 36;
const COUNT = 12;
const SMALL = typeof window !== "undefined" && isSmallGpu();
const STAR_N = SMALL ? 2200 : 7000;
const DISTANT_N = SMALL ? 1600 : 4200;
const STREAK_N = SMALL ? 280 : 720;
const DUST_N = SMALL ? 180 : 380;
const NEBULA = SMALL ? 8 : 14;
const VEIL_N = SMALL ? 4 : 7;

const _dummy = new Object3D();
const _look = new Vector3();
const _cam = new Vector3();
const _up = new Vector3(0, 1, 0);
const _dir = new Vector3();
const _sta = new Vector3();
const _ndc = new Vector3();
const _fwd = new Vector3();
const _right = new Vector3();

const GALAXY_TINT: Record<Constellation["element"], string> = {
  fire: "#f0d4c6",
  earth: "#e6dcc0",
  air: "#eef0ee",
  water: "#d0dde6",
};

const NEBULA_TINT = ["#efe4d2", "#d7e0e8", "#ead8c4", "#e4ddd4", "#cfd6dc", "#e8d0c4", "#c8d4e0"];

function noopRaycast() {
  /* stars never steal constellation picks */
}

function smooth(x: number) {
  const t = Math.min(1, Math.max(0, x));
  return t * t * (3 - 2 * t);
}

function pathAt(t: number, out: Vector3) {
  const z = -t * SPACING;
  out.set(Math.sin(t * 0.53) * 2.1, 0.28 + Math.cos(t * 0.37) * 1.05, z);
  return out;
}

function finishTexture(tex: CanvasTexture) {
  tex.colorSpace = SRGBColorSpace;
  tex.generateMipmaps = false;
  tex.minFilter = LinearFilter;
  tex.magFilter = LinearFilter;
  tex.premultiplyAlpha = true;
  tex.needsUpdate = true;
  return tex;
}

function paintGlow(size: number, inner: string, mid: string) {
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d")!;
  const g = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  g.addColorStop(0, inner);
  g.addColorStop(0.12, mid);
  g.addColorStop(0.4, "rgba(180, 160, 130, 0.06)");
  g.addColorStop(0.72, "rgba(0, 0, 0, 0)");
  g.addColorStop(1, "rgba(0, 0, 0, 0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
  return finishTexture(new CanvasTexture(canvas));
}

function makeGlowTexture() {
  return paintGlow(128, "rgba(255, 246, 230, 0.55)", "rgba(232, 214, 188, 0.18)");
}

/** Wispy nebula sprite — layered blobs plus a faint filament. */
function makeNebulaTexture() {
  const size = 256;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d")!;
  for (const b of [
    { x: 0.5, y: 0.48, r: 0.5, a: 0.52 },
    { x: 0.36, y: 0.42, r: 0.34, a: 0.32 },
    { x: 0.64, y: 0.56, r: 0.3, a: 0.28 },
    { x: 0.46, y: 0.64, r: 0.24, a: 0.2 },
    { x: 0.58, y: 0.38, r: 0.2, a: 0.16 },
  ]) {
    const g = ctx.createRadialGradient(b.x * size, b.y * size, 0, b.x * size, b.y * size, b.r * size);
    g.addColorStop(0, `rgba(255, 246, 230, ${b.a})`);
    g.addColorStop(0.32, `rgba(232, 210, 180, ${b.a * 0.38})`);
    g.addColorStop(0.7, `rgba(160, 140, 120, ${b.a * 0.08})`);
    g.addColorStop(1, "rgba(0, 0, 0, 0)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, size, size);
  }
  ctx.globalCompositeOperation = "lighter";
  ctx.strokeStyle = "rgba(255, 236, 210, 0.14)";
  ctx.lineWidth = 16;
  ctx.lineCap = "round";
  ctx.beg
... 