function SignFigure({ index, data }: { index: number; data: Constellation }) {
  const cores = useRef<Points>(null);
  const wash = useRef<Mesh>(null);
  const nova = useRef<Mesh>(null);
  const art = useRef<Mesh>(null);
  const group = useRef<Group>(null);
  const tint = useMemo(() => new Color(GALAXY_TINT[data.element]), [data.element]);
  const coreMat = useMemo(() => makeSparkMaterial(), []);
  const washTex = useMemo(() => makeNebulaTexture(), []);
  const novaTex = useMemo(() => makeGlowTexture(), []);
  const artTex = useMemo(() => loadSignArt(data.id), [data.id]);
  const pairs = useMemo(() => pairFigures(data.animal, data.glyph), [data.animal, data.glyph]);
  const figureN = pairs.length;
  const dustN = SMALL ? 14 : 22;
  const n = figureN + dustN;
  const dust = useMemo(() => constellationDust(index, dustN), [index, dustN]);
  const scatter = useMemo(() => {
    return Array.from({ length: n }, (_, i) => {
      const a = index * 1.73 + i * 2.399;
      const b = index * 0.91 + i * 1.618;
      const r = 12.5 + (i % 7) * 2.8;
      return new Vector3(Math.cos(a) * r, Math.sin(b) * (7.4 + (i % 5) * 1.1), Math.sin(a) * r * 0.82);
    });
  }, [n, index]);
  const starGeo = useMemo(() => {
    const g = new BufferGeometry();
    g.setAttribute("position", new BufferAttribute(new Float32Array(n * 3), 3));
    g.setAttribute("color", new BufferAttribute(new Float32Array(n * 3), 3));
    g.setAttribute("aSize", new BufferAttribute(new Float32Array(n), 1));
    g.setAttribute("aSpike", new BufferAttribute(new Float32Array(n), 1));
    return g;
  }, [n]);
  const pick = () => useVault.getState().openBirthChat(data.id);

  useEffect(() => {
    return () => {
      coreMat.dispose();
      washTex.dispose();
      novaTex.dispose();
      starGeo.dispose();
    };
  }, [coreMat, washTex, novaTex, starGeo]);

  useFrame(({ camera, clock }) => {
    const mesh = cores.current;
    const aPipe = animalPipe.current;
    const gPipe = glyphPipe.current;
    const g = group.current;
    if (!mesh || !g) return;
    const chatting = useVault.getState().chat;
    const held = chatting && useVault.getState().pickedSign === data.id;
    const along = held ? 0.42 : alongToGate(galaxyTravel.t, index);
    pathAt(galaxyTravel.t + along, g.position);
    pathAt(galaxyTravel.t + along + 0.28, _look);
    if (!Number.isFinite(g.position.x) || !Number.isFinite(_look.x)) return;
    g.lookAt(_look);
    const local = held ? 1 : gateForm(along, index, galaxyTravel.t);
    const form = local * Math.max(galaxyTravel.awaken, held ? 1 : 0);
    const morph = held ? 1 : signMorph(along);
    const burst = held ? 0 : morphBurst(along);
    const plateOn = artReady(artTex);
    if (form < 0.012 && !held) {
      mesh.visible = false;
      if (aPipe) aPipe.visible = false;
      if (gPipe) gPipe.visible = false;
      if (wash.current) wash.current.visible = false;
      if (nova.current) nova.current.visible = false;
      if (art.current) art.current.visible = false;
      return;
    }
    mesh.visible = true;
    if (aPipe) aPipe.visible = false;
    if (gPipe) gPipe.visible = form > 0.22 && morph > 0.12;
    if (art.current) {
      const plate = (1 - morph) * (1 - burst * 0.28);
      const show = plateOn && form > 0.04 && plate > 0.03;
      art.current.visible = show;
      if (show) {
        const aspect = artAspect(artTex);
        const wide = (18.8 + along * 2.4) * (1 + burst * 0.12);
        art.current.scale.set(wide, wide / aspect, 1);
        const am = art.current.material;
        if (!Array.isArray(am) && "opacity" in am) am.opacity = Math.min(1, form * plate);
      }
    }
    if (wash.current) {
      wash.current.visible = form > 0.12 && (morph > 0.18 || burst > 0.04);
      const wm = wash.current.material;
      if (!Array.isArray(wm) && "opacity" in wm) wm.opacity = form * (0.1 + burst * 0.42);
      const ws = 12.5 * (1 + burst * 0.9);
      wash.current.scale.set(ws, 9.2 * (1 + burst * 0.7), 1);
    }
    if (nova.current) {
      const live = burst > 0.02;
      nova.current.visible = live;
      if (live) {
        const ns = 6.2 + burst * 20;
        nova.current.scale.setScalar(ns);
        const nm = nova.current.material;
        if (!Array.isArray(nm) && "opacity" in nm) nm.opacity = burst * 0.58;
      }
    }
    const time = clock.elapsedTime;
    g.updateMatrixWorld();
    const pOn = galaxyTravel.ptrOn;
    const pnx = galaxyTravel.ptrX * 2;
    const pny = -galaxyTravel.ptrY * 2;
    const pos = mesh.geometry.getAttribute("position") as BufferAttribute;
    const col = mesh.geometry.getAttribute("color") as BufferAttribute;
    const sz = mesh.geometry.getAttribute("aSize") as BufferAttribute;
    const sp = mesh.geometry.getAttribute("aSpike") as Buffer
... 