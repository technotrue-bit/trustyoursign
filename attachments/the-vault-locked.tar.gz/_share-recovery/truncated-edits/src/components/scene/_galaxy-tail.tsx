function PointerAura() {
  const group = useRef<Group>(null);
  const tex = useMemo(() => makeAuraTexture(), []);
  const on = useRef(0);
  const want = useRef(new Vector3());

  useEffect(() => () => tex.dispose(), [tex]);

  useFrame(({ camera }, dt) => {
    const g = group.current;
    if (!g) return;
    const live = !useVault.getState().entered && galaxyTravel.ptrOn;
    on.current += ((live ? 1 : 0) - on.current) * (1 - Math.exp(-dt * 7));
    const reduce = prefersReducedMotion();
    const pulse = reduce ? 0 : Math.sin(performance.now() * 0.0018);
    const outer = g.children[0] as Mesh | undefined;
    const inner = g.children[1] as Mesh | undefined;
    const om = outer?.material;
    const im = inner?.material;
    if (om && !Array.isArray(om) && "opacity" in om) om.opacity = on.current * (0.07 + pulse * 0.012);
    if (im && !Array.isArray(im) && "opacity" in im) im.opacity = on.current * (0.11 + pulse * 0.016);
    if (on.current < 0.015) {
      g.visible = false;
      return;
    }
    g.visible = true;
    const dist = 10;
    const cam = camera as PerspectiveCamera;
    const fov = ((cam.fov ?? 58) * Math.PI) / 180;
    const hh = 2 * Math.tan(fov / 2) * dist;
    const ww = hh * (cam.aspect || 1);
    const px = Number.isFinite(galaxyTravel.ptrX) ? galaxyTravel.ptrX : 0;
    const py = Number.isFinite(galaxyTravel.ptrY) ? galaxyTravel.ptrY : 0;
    _fwd.set(0, 0, -1).applyQuaternion(camera.quaternion);
    _right.set(1, 0, 0).applyQuaternion(camera.quaternion);
    _up.set(0, 1, 0).applyQuaternion(camera.quaternion);
    want.current.copy(camera.position).addScaledVector(_fwd, dist);
    want.current.addScaledVector(_right, px * ww);
    want.current.addScaledVector(_up, -py * hh);
    g.position.lerp(want.current, 1 - Math.exp(-dt * 11));
    if (g.position.distanceToSquared(camera.position) > 0.25) g.lookAt(camera.position);
    const sc = reduce ? 1.55 : 1.45 + on.current * 0.28 + pulse * 0.03;
    g.scale.setScalar(sc);
  });

  return (
    <group ref={group} visible={false}>
      <mesh raycast={noopRaycast}>
        <planeGeometry args={[1, 1]} />
        <meshBasicMaterial
          map={tex}
          color="#fff4dc"
          transparent
          opacity={0}
          depthWrite={false}
          depthTest={false}
          blending={AdditiveBlending}
          fog={false}
          toneMapped={false}
        />
      </mesh>
      <mesh raycast={noopRaycast} scale={0.26}>
        <planeGeometry args={[1, 1]} />
        <meshBasicMaterial
          map={tex}
          color="#fff8ec"
          transparent
          opacity={0}
          depthWrite={false}
          depthTest={false}
          blending={AdditiveBlending}
          fog={false}
          toneMapped={false}
        />
      </mesh>
    </group>
  );
}

function GalaxyRig() {
  const { camera, gl } = useThree();
  const target = useRef(galaxyTravel.t);
  const current = useRef(galaxyTravel.t);
  const vel = useRef(0);
  const lookX = useRef(0);
  const lookY = useRef(0);
  const ptrX = useRef(0);
  const ptrY = useRef(0);
  const dragging = useRef(false);
  const lastX = useRef(0);
  const lastY = useRef(0);
  const moved = useRef(galaxyTravel.moved);
  const idle = useRef(0);
  const seeking = useRef(false);
  const lastPublish = useRef(-1);
  const booted = useRef(false);
  const reduce = useRef(false);

  useEffect(() => {
    reduce.current =
      typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    ensureAutoClock();
  }, []);

  useEffect(() => {
    const el = gl.domElement;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      if (useVault.getState().chat) return;
      e.preventDefault();
      if (galaxyTravel.birth < 1) {
        skipBirth();
        useGalaxy.getState().markBorn();
      }
      const scale = e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? 120 : 1;
      const impulse = (e.deltaY * scale + e.deltaX * scale) / 1400;
      vel.current += impulse * 1.15;
      target.current += impulse * 0.35;
      moved.current = true;
      idle.current = 0;

... 