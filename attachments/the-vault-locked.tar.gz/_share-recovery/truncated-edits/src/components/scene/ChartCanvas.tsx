import { useEffect, useRef } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { OrbitControls, Stars } from "@react-three/drei";
import { Color, Vector3 } from "three";
import type { OrbitControls as OrbitControlsImpl } from "three-stdlib";
import { canvasDpr, isSmallGpu } from "@/lib/gpu";
import { lonToXZ } from "@/lib/chart/geometry";
import { getNativity } from "@/lib/chart/nativity";
import type { AppMode, ChakraId, PlanetId } from "@/lib/chart/types";
import { useVault } from "@/lib/store";
import { ChakraBody, DecisionMachine, GatePortals } from "./Figures";
import { GalaxyIntro } from "./GalaxyIntro";
import { SkyWheel } from "./SkyWheel";

type Pose = { position: [number, number, number]; target: [number, number, number] };

const POSES: Record<AppMode, Pose> = {
  sky: { position: [0, 6.4, 9.6], target: [0, 0.1, 0] },
  body: { position: [3.2, 1.7, 5.2], target: [0, 1.15, 0] },
  gates: { position: [0, 1.7, 11.2], target: [0, 1.2, 0] },
  machine: { position: [0, 7.2, 7.6], target: [0, 0, 0] },
  readings: { position: [2.2, 4.4, 8.2], target: [0, 0.2, 0] },
  bones: { position: [0, 12.5, 0.6], target: [0, 0, 0] },
  ask: { position: [2.2, 4.4, 8.2], target: [0, 0.2, 0] },
};

const _pos = new Vector3();
const _tar = new Vector3();

function poseFor(): Pose {
  const { mode, selection, chartId } = useVault.getState();
  const nat = getNativity(chartId ?? "saige");
  if (selection?.kind === "planet") {
    const p = nat.planetById[selection.id as PlanetId];
    if (p) {
      const [x, z] = lonToXZ(p.lon, p.radius, nat.angles);
      const len = Math.hypot(x, z) || 1;
      const push = 3.1;
      return {
        position: [x + (x / len) * push, 2.35, z + (z / len) * push],
        target: [x, 0.2, z],
      };
    }
  }
  if (selection?.kind === "chakra") {
    const c = nat.chakraById[selection.id as ChakraId];
    if (c) return { position: [2.6, c.y + 0.35, 4.0], target: [0, c.y, 0] };
  }
  if (selection?.kind === "gate") {
    const x = selection.id === "rising" ? -3.15 : selection.id === "moon" ? 3.15 : 0;
    return { position: [x * 0.2, 1.55, 6.4], target: [x, 1.4, 0] };
  }
  if (selection?.kind === "step") {
    const i = Number(selection.id) - 1;
    const a = (i / 6) * Math.PI * 2 - Math.PI / 2;
    const x = Math.cos(a) * 3.2;
    const z = Math.sin(a) * 3.2;
    return { position: [x * 0.45, 4.6, z * 0.45 + 6.2], target: [x, 0.2, z] };
  }
  return POSES[mode];
}

function CameraRig() {
  const controls = useRef<OrbitControlsImpl>(null);
  const mode = useVault((s) => s.mode);
  const selection = useVault((s) => s.selection);
  const entered = useVault((s) => s.entered);
  const lerpUntil = useRef(0);
  const booted = useRef(false);

  useEffect(() => {
    lerpUntil.current = performance.now() + 1600;
  }, [mode, selection]);

  useFrame((_, delta) => {
    const c = controls.current;
    if (!c) return;
    const d = Math.min(delta, 0.1);
    const now = performance.now();
    if (!booted.current) {
      const pose = poseFor();
      c.object.position.set(...pose.position);
      c.target.set(...pose.target);
      c.update();
      booted.current = true;
      lerpUntil.current = 0;
      return;
    }
    if (now < lerpUntil.current) {
      const pose = poseFor();
      const k = 1 - Math.exp(-d * 2.4);
      c.object.position.lerp(_pos.set(...pose.position), k);
      c.target.lerp(_tar.set(...pose.target), k);
      c.update();
    }
  });

  const auto = entered && mode === "sky" && !selection;

  return (
    <OrbitControls
      ref={controls}
      makeDefault
      enablePan={false}
      enableDamping
      dampingFactor={0.08}
      minDistance={3.2}
      maxDistance={22}
      maxPolarAngle={Math.PI * 0.48}
      minPolarAngle={0.18}
      autoRotate={auto}
      autoRotateSpeed={0.28}
      enabled={entered}
    />
  );
}

function SceneBody() {
  const mode = useVault((s) => s.mode);
  const entered = useVault((s) => s.entered);
  const { gl } = useThree();

  useEffect(() => {
    gl.setClearColor(new Color("#0c0b0a"));
  }, [gl]);

  const skyOn = mode === "sky" || mode === "bones" || mode === "readings" || mode === "ask";
  const bodyOn = mode === "body";
  const gatesOn = mode === "gates";
  const machineOn = mode === "machine";

  return (
    <>
      <color attach="background" args={["#0c0b0a"]} />
      <fog attach="fog" args={["#0c0b0a", 16, 42]} />
      <ambientLight intensity={0.35} />
      <Stars radius={70} depth={28} count={entered ? 2800 : 1600} factor={2.6} saturation={0
... 