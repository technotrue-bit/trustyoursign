import { CanvasTexture, ClampToEdgeWrapping, LinearFilter, SRGBColorSpace } from "three";
import type { SignId } from "@/lib/chart/types";

export const SIGN_ART: Record<SignId, string> = {
  aries: "/signs/aries.png",
  taurus: "/signs/taurus.png",
  gemini: "/signs/gemini.png",
  cancer: "/signs/cancer.png",
  leo: "/signs/leo.png",
  virgo: "/signs/virgo.png",
  libra: "/signs/libra.png",
  scorpio: "/signs/scorpio.png",
  sagittarius: "/signs/sagittarius.png",
  capricorn: "/signs/capricorn.png",
  aquarius: "/signs/aquarius.png",
  pisces: "/signs/pisces.png",
};

const W = 1024;
const H = 576;
const images = new Map<string, HTMLImageElement>();
const textures = new Map<string, CanvasTexture>();
const painted = new Set<string>();
const aspects = new Map<string, number>();

function style(tex: CanvasTexture) {
  tex.colorSpace = SRGBColorSpace;
  tex.generateMipmaps = false;
  tex.minFilter = LinearFilter;
  tex.magFilter = LinearFilter;
  tex.wrapS = ClampToEdgeWrapping;
  tex.wrapT = ClampToEdgeWrapping;
  tex.premultiplyAlpha = false;
}

function blankCanvas() {
  const c = document.createElement("canvas");
  c.width = W;
  c.height = H;
  return c;
}

function ensureImage(id: SignId) {
  const url = SIGN_ART[id];
  let img = images.get(url);
  if (img) return img;
  img = new Image();
  img.decoding = "async";
  img.onload = () => {
    painted.delete(url);
    const tex = textures.get(url);
    if (tex) raster(id, tex);
  };
  img.onerror = () => {
    window.setTimeout(() => {
      images.delete(url);
      ensureImage(id);
    }, 500);
  };
  img.src = url;
  images.set(url, img);
  return img;
}

function raster(id: SignId, tex: CanvasTexture) {
  const url = SIGN_ART[id];
  const img = images.get(url);
  if (!img || !img.complete || (img.naturalWidth ?? 0) < 2) return false;
  const canvas = tex.image as HTMLCanvasElement;
  const ctx = canvas.getContext("2d", { alpha: true });
  if (!ctx) return false;
  ctx.clearRect(0, 0, W, H);
  const ir = img.naturalWidth / Math.max(1, img.naturalHeight);
  const cr = W / H;
  let dw: number;
  let dh: number;
  let dx: number;
  let dy: number;
  if (ir > cr) {
    dw = W;
    dh = dw / ir;
    dx = 0;
    dy = (H - dh) / 2;
  } else {
    dh = H;
    dw = dh * ir;
    dy = 0;
    dx = (W - dw) / 2;
  }
  ctx.drawImage(img, dx, dy, dw, dh);
  aspects.set(url, img.naturalWidth / Math.max(1, img.naturalHeight));
  style(tex);
  tex.needsUpdate = true;
  painted.add(url);
  return true;
}

export function hydrateSignArt(id: SignId, tex: CanvasTexture) {
  if (painted.has(SIGN_ART[id]) && (tex.image as HTMLCanvasElement).width === W) return true;
  ensureImage(id);
  return raster(id, tex);
}

export function loadSignArt(id: SignId): CanvasTexture {
  const url = SIGN_ART[id];
  const hit = textures.get(url);
  if (hit) {
    hydrateSignArt(id, hit);
    return hit;
  }
  const tex = new CanvasTexture(blankCanvas());
  style(tex);
  textures.set(url, tex);
  ensureImage(id);
  hydrateSignArt(id, tex);
  return tex;
}

export function preloadSignArt() {
  if (typeof window === "undefined") return;
  (Object.keys(SIGN_ART) as SignId[]).forEach((id) => ensureImage(id));
}

export function artReady(tex: CanvasTexture) {
  for (const [url, t] of textures) {
    if (t === tex) return painted.has(url);
  }
  return false;
}

export function artAspect(tex: CanvasTexture, fallback = 1.78) {
  for (const [url, t] of textures) {
    if (t === tex) return aspects.get(url) ?? fallback;
  }
  return fallback;
}

export function signArtImage(id: SignId): HTMLImageElement {
  return ensureImage(id);
}

export function plateReady(id: SignId) {
  return painted.has(SIGN_ART[id]) || Boolean(
    images.get(SIGN_ART[id])?.complete && (images.get(SIGN_ART[id])?.naturalWidth ?? 0) > 2,
  );
}
