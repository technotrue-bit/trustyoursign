/** Shared mutable travel. Written every frame by the camera. Not React state. */
import { CONSTELLATIONS, nearestSign, signStation, signedDelta, wrap12 } from "./constellations";
import { loadSignArt } from "./signArt";
import { useGalaxy } from "./store";

export { signedDelta, wrap12 };

export const BIRTH_SECONDS = 3.85;
/** Idle drift toward you. Keep this low — the sky should feel patient. */
export const CRUISE = 0.14;
/** After a jump, ease through animal → explosion → glyph. Patient so the stars can gather. */
export const PLAY_CRUISE = 0.48;
/** Slide or hold the sky to fly — medium, same both ways. */
export const HOLD_FLY = 0.58;
export const MAX_FLY = 1.12;
/** World units along −Z per t. Signs sit farther apart so the burst can read. */
export const SPACING = 50;
/** Sign sits this far ahead of its station. You still fly through it while its name is up. */
export const GATE = 0.55;
/** Hands off: dwell, then walk to the next sign. */
export const AUTO_SIGN = 7;
/** Animal holds until this along. */
export const MORPH_FAR = 0.92;
/** Glyph is complete by this along — middle of the remaining approach. */
export const MORPH_NEAR = 0.42;
/** Stars are still out in the field. */
export const GATHER_FAR = 2.55;
/** Stars have locked into the picture. */
export const GATHER_LOCK = 1.12;
/** Land this far before the station so the ram is still a ram. */
export const SEEK_ARRIVE = 0.55;
/** Cruise this far past the station so the explosion finishes, then the glyph passes. */
export const SEEK_THROUGH = 0.34;
/** Never skip more than ~2 frames of birth, even after a load hitch. */
const BIRTH_DT_CAP = 0.032;
/** First look starts on the ram, before the Aries station. */
const OPEN_T = -SEEK_ARRIVE;

let reduceCache = false;
let reduceAt = -1e9;
let autoClock = 0;
let autoLast = 0;

export const galaxyTravel = {
  t: OPEN_T,
  moved: false,
  seek: null as number | null,
  /** Keep flying until this t so a jump plays animal → burst → glyph. */
  playUntil: null as number | null,
  awaken: 0,
  /** World-units per second along the flight path. */
  speed: 0,
  /** 0 → 1 first-load star birth. 1 means the sky is open. */
  birth: 0,
  /** Pointer in view, −0.5…0.5. */
  ptrX: 0,
  ptrY: 0,
  ptrOn: false,
  /** Seconds since the last steering input. Shared by 2D and 3D. */
  idle: 0,
  /** performance.now() when idle began. Wall-clock so a paused renderer still counts. */
  idleAt: 0,
  /** True while the pointer is dragging the sky. */
  handsOn: false,
  /** True while a seek is interpolating. */
  traveling: false,
  /** Chat, vault, or still birthing — don't auto-walk. */
  busy: false,
  /** −1 reverse, 0 none, +1 forward. Held while a finger or the wheel is down. */
  hold: 0,
  /** Impulse consumed once per frame by the camera. */
  steer: 0,
  /** Pointer still down on the sky. */
  dragging: false,
  /** performance.now() until a wheel flick still counts as hands-on. */
  wheelUntil: 0,
};

export function prefersReducedMotion() {
  if (typeof window === "undefined") return false;
  const now = typeof performance !== "undefined" ? performance.now() : Date.now();
  if (now - reduceAt > 800) {
    reduceAt = now;
    reduceCache = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }
  return reduceCache;
}

function smooth01(x: number) {
  const t = Math.min(1, Math.max(0, x));
  return t * t * (3 - 2 * t);
}

function nowMs() {
  return typeof performance !== "undefined" ? performance.now() : Date.now();
}

function restIdle() {
  galaxyTravel.idle = 0;
  galaxyTravel.idleAt = nowMs();
}

/** Advance the opening birth one display frame. Capped so a hitch never jumps the boom. */
export function stepBirth(dt?: number) {
  if (galaxyTravel.birth >= 1) return false;
  if (prefersReducedMotion()) {
    galaxyTravel.birth = 1;
    return true;
  }
  const raw = typeof dt === "number" && Number.isFinite(dt) && dt > 0 ? dt : 1 / 60;
  const step = Math.min(raw, BIRTH_DT_CAP);
  const before = galaxyTravel.birth;
  galaxyTravel.birth = Math.min(1, galaxyTravel.birth + step / BIRTH_SECONDS);
  return before < 1 && galaxyTravel.birth >= 1;
}

export function skipBirth() {
  if (galaxyTravel.birth >= 1) return false;
  galaxyTravel.birth = 1;
  galaxyTravel.awaken = 1;
  const sign = CONSTELLATIONS[i];
  if (sign) loadSignArt(sign.id);
  restIdle();
  return true;
}

export function resetTravel(replayBirth: boolean) {
  galaxyTravel.t = OPEN_T;
  galaxyTravel.moved = false;
  galaxyTravel.seek = null;
  galaxyTravel.playUntil = SEEK_THROUGH;
  galaxyTravel.awaken = 0;
  galaxyTravel.speed = 0;
  galaxyTravel.birth = replayBirth ? 0 : 1;
  galaxyTravel.ptrOn = false;
  galaxyTravel.handsOn = false;
  galaxyTravel.traveling = false;
  galaxyTravel.busy = fal
... 