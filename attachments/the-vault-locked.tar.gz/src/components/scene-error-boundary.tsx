import { Component, type ErrorInfo, type ReactNode } from "react";

type Props = { fallback: ReactNode; children: ReactNode };

export class SceneErrorBoundary extends Component<Props, { dead: boolean }> {
  state = { dead: false };
  static getDerivedStateFromError() {
    return { dead: true };
  }
  componentDidCatch(error: Error, info: ErrorInfo) {
    console.warn("vault scene", error, info);
    window.dispatchEvent(new Event("vault-webgl-lost"));
  }
  render() {
    return this.state.dead ? this.props.fallback : this.props.children;
  }
}
