import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { VaultApp } from "@/components/overlay/VaultApp";
import "@/styles.css";

createRoot(document.getElementById("app")!).render(
  <StrictMode>
    <VaultApp />
  </StrictMode>,
);
