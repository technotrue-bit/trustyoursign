# Locked plate pipeline

Snapshot of the first-working Imagine plate renderer (Aries through Pisces).

Future galaxy tweaks must not touch public/signs or this path unless Joey/Horus says so.

Do not replace the original Imagine plates in public/signs/{aries...pisces}.png.
Do not invent art.
Do not publish.

## Rules of the locked path

- Plates are always-on art for the focused/incoming sign.
- Do NOT gate plate opacity on morph/burst.
- Do NOT unmount off-screen SignFigures into a blank-canvas remount. Keep all 12 mounted.
- Paint per-texture (WeakSet / independent canvas). Never skip raster because another canvas for the same URL was painted. Do not dispose sign textures.
- Billboarded, depthTest false, high renderOrder so plates actually show.

## Live sources (must stay in lockstep with this snapshot)

- src/lib/galaxy/signArt.ts
- src/components/scene/GalaxyIntro.tsx (SignFigure plate mesh; all 12 stay in the tree)

travel.ts does not unmount signs. Seek only primes PNG loads (primeSignArt).

## Confirmations

- All 12 SignFigures stay mounted (CONSTELLATIONS.map, no off-screen unmount).
- Plate opacity is not morph-gated: focused/held = 1, incoming = 0.72. Morph/burst only drive star figure and nova.

## Run

Use the project dev server.
