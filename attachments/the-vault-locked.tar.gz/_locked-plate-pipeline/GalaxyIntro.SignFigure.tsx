function SignFigure({ index, data }: { index: number; data: Constellation }) {
  const cores = useRef<Points>(null);
  const art = useRef<Mesh>(null);
  const nova = useRef<Mesh>(null);
  const group = useRef<Group>(null);
  const tint = useMemo(() => new Color(GALAXY_TINT[data.element]), [data.element]);
  const artTex = useMemo(() => loadSignArt(data.id), [data.id]);
  const spark = useMemo(() => makeSparkTexture(), []);
  const pairs = useMemo(() => pairFigures(data.animal, data.figure), [data.animal, data.figure]);
  const figureN = pairs.length;
  const dustN = SMALL ? 14 : 22;
  const n = figureN + dustN;
  const dust = useMemo(() => constellationDust(index, dustN), [index, dustN]);
  const scatter = useMemo(() => {
    return Array.from({ length: n }, (_, i) => {
      const a = index * 1.73 + i * 2.399;
      const b = index * 0.91 + i * 1.618;
      const r = 12.5 + (i % 7) * 2.8;
      return new Vector3(Math.cos(a) * r, Math.sin(b) * (7.4 + (i % 5) * 1.1), Math.sin(a) * r * 0.82);
    });
  }, [n, index]);
  const starGeo = useMemo(() => {
    const g = new BufferGeometry();
    g.setAttribute("position", new BufferAttribute(new Float32Array(n * 3), 3));
    g.setAttribute("color", new BufferAttribute(new Float32Array(n * 3), 3));
    return g;
  }, [n]);
  const pick = () => useVault.getState().openBirthChat(data.id);

  useEffect(() => {
    return () => {
      spark.dispose();
      starGeo.dispose();
      // LOCKED: never dispose artTex / sign canvases.
    };
  }, [spark, starGeo]);

  useFrame(({ camera, clock }) => {
    const mesh = cores.current;
    const g = group.current;
    if (!mesh || !g) return;
    hydrateSignArt(data.id, artTex);
    const chatting = useVault.getState().chat;
    const held = chatting && useVault.getState().pickedSign === data.id;
    const along = held ? 0.42 : alongToGate(galaxyTravel.t, index);
    const nIdx = nearestSign(galaxyTravel.t);
    const incoming = index === (nIdx + 1) % COUNT;
    const focused = held || index === aimedIndex() || index === nIdx;
    pathAt(index, g.position);
    g.quaternion.copy(camera.quaternion);
    const local = held ? 1 : gateForm(along, index, galaxyTravel.t);
    const form =
      Math.max(
        local,
        focused && along < 2.9 && along > -0.35 ? 0.97 : incoming && along < 2.1 && along > 0.15 ? 0.78 : 0,
      ) * Math.max(galaxyTravel.awaken, held || focused || incoming ? 1 : 0);
    const cinematic = !held && galaxyTravel.playUntil != null;
    const morph = held ? 1 : cinematic ? signMorph(along) : focused ? Math.min(signMorph(along), 0.35) : 0;
    const burst = held ? 0 : cinematic ? morphBurst(along) : 0;
    const plateOn = artReady(artTex);

    if (form < 0.008 && !held && !focused && !incoming) {
      mesh.visible = false;
      if (art.current) art.current.visible = false;
      if (nova.current) nova.current.visible = false;
      return;
    }
    mesh.visible = true;

    const pos = mesh.geometry.getAttribute("position") as BufferAttribute;
    const col = mesh.geometry.getAttribute("color") as BufferAttribute;
    const time = clock.elapsedTime;
    for (let i = 0; i < n; i++) {
      const isDust = i >= figureN;
      const gather = starGather(along, i, n);
      const sc = scatter[i]!;
      let x: number;
      let y: number;
      let z: number;
      let mag: number;
      if (isDust) {
        const d = dust[i - figureN]!;
        mag = d.mag;
        if (form < 0.18 || morph < 0.12) {
          pos.setXYZ(i, 0, 80, 0);
          col.setXYZ(i, 0, 0, 0);
          continue;
        }
        x = d.x;
        y = d.y;
        z = ((i % 3) - 1) * 0.16;
      } else {
        const p = pairs[i]!;
        mag = p.am + (p.gm - p.am) * morph;
        const fx = (p.ax + (p.gx - p.ax) * morph) * 1.08;
        const fy = (p.ay + (p.gy - p.ay) * morph) * 1.08;
        const kick = 1 + burst * 0.82;
        x = fx * gather * kick + sc.x * (1 - gather);
        y = fy * gather * kick + sc.y * (1 - gather);
        z = sc.z * (1 - gather) * 0.4;
      }
      pos.setXYZ(i, x, y, z);
      const sparkle = starSpark(time, i, index * 1.7);
      const b = Math.min(1.18, sparkle * (0.5 + mag * 0.55) * (0.35 + form * 0.75 + burst * 0.28));
      const lift = 0.58 + mag * 0.42;
      col.setXYZ(i, tint.r * lift * b, tint.g * lift * b, tint.b * lift * b);
    }
    pos.needsUpdate = true;
    col.needsUpdate = true;

    if (art.current) {
      const mat = art.current.material as MeshBasicMaterial;
      // LOCKED: always-on art for focused/incoming. Do not gate opacity on morph/burst.
      const plateVis = (focused || incoming || held) && along > -0.55 && along < 2.6;
      const show = plateVis && plateOn;
      art.current.visible = show;
      art.current.frustumCulled = false;
      art.current.renderOrder = 10;
      if (show) {
        const aspect = artAspect(artTex);
        const wide = (SMALL ? 22.5 : 19.4) + Math.min(Math.max(along, 0), 1.2) * 1.6;
        art.current.scale.set(wide, wide / aspect, 1);
        mat.opacity = focused || held ? 1 : incoming ? 0.72 : 0.9;
        mat.map = artTex;
        mat.depthTest = false;
        mat.depthWrite = false;
        mat.needsUpdate = true;
      } else {
        mat.opacity = 0;
      }
    }
    if (nova.current) {
      nova.current.visible = burst > 0.04;
      nova.current.scale.setScalar(6.2 + burst * 20);
      const nm = nova.current.material as MeshBasicMaterial;
      nm.opacity = burst * 0.58;
    }
  });

  return (
    <group ref={group} frustumCulled={false} onClick={(e) => { e.stopPropagation(); pick(); }}>
      <mesh
        ref={art}
        position={[0, 0.05, -0.06]}
        visible={false}
        renderOrder={10}
        frustumCulled={false}
      >
        <planeGeometry args={[1, 1]} />
        <meshBasicMaterial
          map={artTex}
          color="#ffffff"
          transparent
          opacity={0}
          depthWrite={false}
          depthTest={false}
          fog={false}
          toneMapped={false}
          side={DoubleSide}
        />
      </mesh>
      <mesh ref={nova} position={[0, 0, -0.2]} visible={false} renderOrder={5} frustumCulled={false}>
        <planeGeometry args={[1, 1]} />
        <meshBasicMaterial
          map={spark}
          color={tint}
          transparent
          opacity={0}
          depthWrite={false}
          blending={AdditiveBlending}
          fog={false}
          toneMapped={false}
        />
      </mesh>
      <points ref={cores} geometry={starGeo} frustumCulled={false}>
        <pointsMaterial
          map={spark}
          vertexColors
          size={SMALL ? 3.1 : 2.6}
          sizeAttenuation
          transparent
          depthWrite={false}
          blending={AdditiveBlending}
          toneMapped={false}
          fog={false}
        />
      </points>
    </group>
  );
}

