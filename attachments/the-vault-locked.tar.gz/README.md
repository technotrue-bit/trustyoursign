# The Vault

Galaxy zodiac front door (Three.js / React Three Fiber / Vite) with a natal+chakra temple behind it.

Local durable copy recovered from Grok Build share e643dded-8c9b-482f-aacd-5ff61d404992. Not published.

Install dependencies, then start the Vite dev server. Open http://localhost:5173/ and fly Aries through Pisces; each sign should show its art plate, not only the name.

Optional QA query: /?skipBirth=1&sign=taurus
